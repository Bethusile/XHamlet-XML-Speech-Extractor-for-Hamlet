import org.w3c.dom.*;
import org.w3c.dom.ls.DOMImplementationLS;
import org.w3c.dom.ls.LSOutput;
import org.w3c.dom.ls.LSSerializer;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        try {
            loadXML();
        } catch (Exception e) {
            System.out.println("Error occurred:");
            e.printStackTrace();
        }
    }

    public static List<String> GetPersona(Document doc) {
        Set<String> personaSet = new HashSet<>();
        NodeList speechList = doc.getElementsByTagName("SPEECH");
        for (int i = 0; i < speechList.getLength(); i++) {
            Element element = (Element) speechList.item(i);
            NodeList speakerList = element.getElementsByTagName("SPEAKER");
            for (int j = 0; j < speakerList.getLength(); j++) {
                Element speaker = (Element) speakerList.item(j);
                personaSet.add(speaker.getTextContent().trim().toUpperCase());
            }
        }
        return new ArrayList<>(personaSet);
    }

    public static void loadXML() throws ParserConfigurationException, IOException, SAXException {
        Scanner scanner = new Scanner(System.in);
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();

        File fin = new File("hamlet.xml");
        if (!fin.exists()) {
            System.out.println("Error: The file 'hamlet.xml' does not exist.");
            return;
        }

        Document doc = builder.parse(fin);
        System.out.println("XML loaded.");

        List<String> personaList = GetPersona(doc);

        System.out.println("Enter the persona name: eg KING CLAUDIUS, BERNARDO, HORATIO");
        String name = scanner.nextLine().trim().toUpperCase();

        while (!personaList.contains(name)) {
            System.out.println("The persona '" + name + "' is not in the list. Please try again:");
            name = scanner.nextLine().trim().toUpperCase();
        }

        System.out.println("The persona '" + name + "' is valid.");

        Document outputDoc = CreateAndSaveXML(doc, name);

        if (outputDoc != null && outputDoc.getDocumentElement().hasChildNodes()) {
            try {
                String filename = name.toLowerCase().replace(" ", "_") + ".xml";
                saveDoc(outputDoc, filename);
                System.out.println("Output saved to " + filename);
            } catch (Exception e) {
                System.out.println("Error saving document: " + e.getMessage());
            }
        } else {
            System.out.println("No speeches found for persona: " + name);
        }
    }

    public static void saveDoc(Document doc, String filename) throws Exception {
        DOMImplementation impl = doc.getImplementation();
        DOMImplementationLS implLS = (DOMImplementationLS) impl.getFeature("LS", "3.0");
        LSSerializer serializer = implLS.createLSSerializer();
        serializer.getDomConfig().setParameter("format-pretty-print", true);

        FileOutputStream fos = new FileOutputStream(filename);
        LSOutput output = implLS.createLSOutput();
        output.setEncoding("UTF-8");
        output.setByteStream(fos);

        serializer.write(doc, output);
        fos.close();
    }

    public static Document CreateAndSaveXML(Document doc, String personaName)
            throws ParserConfigurationException {

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document output = builder.newDocument();

        Element playElement = output.createElement("Play");
        output.appendChild(playElement);

        NodeList actList = doc.getElementsByTagName("ACT");

        for (int i = 0; i < actList.getLength(); i++) {
            Element actElement = (Element) actList.item(i);
            String actTitle = actElement.getElementsByTagName("TITLE").item(0).getTextContent().trim();

            Element newAct = output.createElement("act");
            newAct.setAttribute("title", actTitle);
            playElement.appendChild(newAct);

            NodeList sceneList = actElement.getElementsByTagName("SCENE");
            for (int j = 0; j < sceneList.getLength(); j++) {
                Element sceneElement = (Element) sceneList.item(j);
                String sceneTitle = sceneElement.getElementsByTagName("TITLE").item(0).getTextContent().trim();

                Element newScene = output.createElement("scene");
                newScene.setAttribute("title", sceneTitle);
                newAct.appendChild(newScene);

                NodeList speechList = sceneElement.getElementsByTagName("SPEECH");
                int speechCounter = 0;

                for (int k = 0; k < speechList.getLength(); k++) {
                    Element speechElement = (Element) speechList.item(k);
                    NodeList speakerList = speechElement.getElementsByTagName("SPEAKER");

                    boolean match = false;
                    for (int s = 0; s < speakerList.getLength(); s++) {
                        String speakerName = speakerList.item(s).getTextContent().trim().toUpperCase();
                        if (personaName.equalsIgnoreCase(speakerName)) {
                            match = true;
                            break;
                        }
                    }

                    if (match) {
                        Element newSpeech = output.createElement("speech");
                        newSpeech.setAttribute("id", String.valueOf(++speechCounter));
                        newSpeech.setAttribute("speaker", personaName);
                        newScene.appendChild(newSpeech);

                        NodeList lineList = speechElement.getElementsByTagName("LINE");
                        for (int l = 0; l < lineList.getLength(); l++) {
                            String lineText = lineList.item(l).getTextContent().trim();

                            Element newLine = output.createElement("line");
                            newLine.setTextContent(lineText);
                            newSpeech.appendChild(newLine);
                        }
                    }
                }
            }
        }

        return output;
    }
}
